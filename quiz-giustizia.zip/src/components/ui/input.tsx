
import React from 'react'
export function Input(props: any) { return <input className={'input ' + (props.className ?? '')} {...props} /> }
