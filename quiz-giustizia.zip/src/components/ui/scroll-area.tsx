
import React from 'react'
export function ScrollArea({ className='', children }: any){ return <div className={'scroll-area ' + className}>{children}</div> }
