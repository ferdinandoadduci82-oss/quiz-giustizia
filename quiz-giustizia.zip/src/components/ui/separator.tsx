
import React from 'react'
export function Separator(){ return <div className='separator' /> }
