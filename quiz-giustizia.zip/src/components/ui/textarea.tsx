
import React from 'react'
export function Textarea(props: any) { return <textarea className={'textarea ' + (props.className ?? '')} {...props} /> }
