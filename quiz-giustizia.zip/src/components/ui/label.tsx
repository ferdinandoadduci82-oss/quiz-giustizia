
import React from 'react'
export function Label(props: any){ return <label className={'text-sm text-slate-700 ' + (props.className ?? '')} {...props} /> }
