
QUIZ PERSONALE – CONCORSO GIUSTIZIA

COME PUBBLICARLA IN 5 PASSI (VERCEL – SEMPLICE):
1) Vai su https://github.com e crea un nuovo repository (New → Name: quiz-giustizia).
2) Clicca “Add file” → “Upload files” e carica TUTTO il contenuto di questa cartella (o lo zip scompattato).
3) Vai su https://vercel.com/new e clicca “Import Git Repository”, scegli il repo “quiz-giustizia”.
4) Conferma. Vercel fa tutto e ti mostra un link del tipo https://quiz-giustizia.vercel.app
5) Apri quel link dal telefono → “Aggiungi a schermata Home” per averla come app.

SVILUPPO LOCALE (FACOLTATIVO):
- Richiede Node.js.
- Nel terminale: 
    npm install
    npm run dev
- Apri l’indirizzo indicato (di solito http://localhost:5173).
